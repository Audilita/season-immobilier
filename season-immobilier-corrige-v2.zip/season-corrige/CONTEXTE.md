# Season Immobilier — note de reprise

Application de gestion locative de SCI Season Immobilier (Abidjan, Côte d'Ivoire).
Ce document donne le contexte nécessaire pour reprendre le développement.

---

## 1. Ce qu'est cette application

Un **fichier HTML unique** de ~19 200 lignes, ~1 148 Ko, qui contient tout :
structure, styles, et l'intégralité du code React.

- **React 18** chargé depuis un CDN, **JSX transpilé par Babel dans le navigateur**
  (pas d'étape de compilation, pas de `npm`, pas de bundler)
- **Tailwind CSS** via CDN
- **Supabase** pour la persistance et l'authentification
- Hébergement **Netlify**, déploiement par dépôt du fichier sur GitHub
  (dépôt `Audilita/season-immobilier`, adresse `seasonimmobilier2026.netlify.app`)

Il n'y a **pas de projet Node**, pas de `package.json`. Ouvrir le fichier dans un
navigateur suffit à faire tourner l'application.

**Utilisateurs :** la gérante et cinq collaborateurs. L'agence travaille dessus
quotidiennement — c'est un outil de production, pas un prototype.

---

## 2. Contrainte structurelle majeure

**Toutes les données tiennent dans une seule ligne d'une seule table Supabase.**

La table `agence` contient une colonne JSON qui stocke l'objet complet : biens,
locataires, propriétaires, paiements, factures, reçus, cautions, mandats,
paramètres. À chaque enregistrement, tout le blob est réécrit.

Conséquences vécues :
- des refus d'enregistrement quand le blob dépasse ~1 Mo (des photos en base64
  y étaient stockées ; elles ont été sorties vers une table `photos`)
- des écrasements entre utilisateurs simultanés : le dernier qui enregistre
  gagne, les modifications de l'autre sont perdues

C'est la dette technique principale. Une migration vers des tables relationnelles
serait le chantier le plus utile, mais elle est lourde et n'a pas été entreprise.

**Tables existantes :** `agence`, `photos`, `candidatures`, `journal`, `vitrine`,
`vitrine_photos`.

---

## 3. Sécurité — point ouvert important

**Les permissions n'existent que côté navigateur.** Les rôles (gérante,
commercial, community manager) filtrent l'affichage des onglets, mais **rien
n'est appliqué côté serveur** : la sécurité au niveau des lignes (RLS) n'est
pas active sur les tables sensibles.

Concrètement, tout utilisateur authentifié peut lire et écrire l'intégralité de
la base, y compris la caisse et les commissions, via l'API Supabase.

Un script SQL de mise en place des politiques RLS a été rédigé mais **n'a jamais
été exécuté**. C'est le point le plus sérieux à traiter.

Par ailleurs le **dépôt GitHub est public**, ce qui expose la clé Supabase
publique présente dans le fichier.

---

## 4. Organisation du code

Tout est dans `<script type="text/babel">`. Structure générale :

1. **Constantes et utilitaires** (~lignes 250-600) — palette de couleurs `C`,
   formatage `fcfa`/`fmt`, dates `aujourdhui`/`addMois`/`dateLongue`,
   `normaliser`, `uid`, `enLettres`
2. **Fonctions métier globales** — commission, pénalités, cautions, dossiers,
   listes de sanctions
3. **Composants d'interface partagés** — `Btn`, `Input`, `Select`, `Field`,
   `Modal`, `Head`, `Tag`, `Row`, `Empty`, `BarreRecherche`, `EnTete`, `PiedPage`
4. **Documents imprimables** — `DocumentLoyer`, `DocumentRecu`, `Quittance`,
   `FactureMeuble`, `PointProprietaire`
5. **Modules métier** — un composant par onglet, ~35 modules
6. **Coquille applicative** — `Racine`, `RacinePrivee`, menu, routage par onglet

Les composants sont déclarés avec `function`, donc remontés : l'ordre de
définition n'a pas d'importance. Les `const` en revanche doivent précéder leur
usage.

---

## 5. Règles métier à connaître

**Commission.** Elle porte sur le **loyer nu**, jamais sur les charges. Quand un
encaissement porte son montant attendu (`p.attendu`), c'est lui qui fait foi et
non le loyer actuel du bien — sinon une révision de loyer fausserait
rétroactivement les commissions des mois anciens. Les charges sont servies en
premier sur un paiement partiel.

**Charges.** Deux natures à ne pas confondre :
- *refacturées au locataire* (eau, électricité, ordures) : champ `charges` du
  bien, ajoutées au loyer sur la quittance, **conservées par l'agence**, jamais
  reversées, hors commission
- *à la charge du propriétaire* (syndic, travaux, procédure) : module
  « Charges & factures complémentaires », déduites de son reversement

Les charges peuvent être instituées en cours de bail : `chargesDepuis` fixe le
mois d'entrée en vigueur, `chargesAvant` ce qui s'appliquait auparavant.

**Caution.** Le montant est **figé** sur la fiche du locataire (`cautionMontant`)
au moment de la saisie. Une révision de loyer ne doit jamais le recalculer —
sinon la restitution serait fausse.

Quatre décisions possibles sur un dépôt, prises depuis le relevé propriétaire :
reverser au propriétaire, affecter aux frais engagés (partiellement possible),
conserver à l'agence, restituer au locataire. Plus un mécanisme d'**avance** :
l'agence puise dans le dépôt d'un locataire en place pour financer des travaux
du propriétaire ; la somme reste due au locataire et le relevé le rappelle.

**Relevé propriétaire.** Un mois déficitaire n'est pas versé : le solde se
reporte sur le suivant jusqu'à ce qu'une recette l'absorbe. C'est le cas d'un
bien vacant sur lequel des travaux ont été engagés.

**Numérotation.** Le numéro de dossier appartient au **bien**, pas à l'affaire :
`DOS-2026-DPL-0001-A`. Année d'enregistrement, code de commune sur trois lettres,
rang du bien, lettre de l'occupant. Il suit factures, reçus et quittances.

**Départ d'un locataire.** `actif: false` libère le bien ; le rattachement
`bienId` est **conservé** — c'est lui qui relie le locataire à ses quittances
passées. Ne jamais supprimer un locataire qui part : son historique serait perdu.

---

## 6. Fragilités connues et pièges

**L'impression.** L'application masque tout sauf le document via
`visibility: hidden`. Les conteneurs occupent donc toujours leur place : les
règles `@media print` neutralisent explicitement `#racine div` (largeur, marges,
positionnement) pour que le document parte du haut et occupe la largeur. **Ne
jamais remettre `position: absolute` ou `fixed`** sur `.zone-impression` ou
`.pied-page` : cela sort l'élément du flux et le contenu s'écrit par-dessus.

**Le téléchargement PDF** n'utilise pas l'impression du navigateur : il capture
le document avec html2canvas et découpe l'image. La découpe cherche une bande
horizontale vierge avant de couper — sans quoi elle tranche au milieu du texte.

**Les listes de sanctions.** La comparaison de noms est délicate : trop
permissive, elle noie sous les faux positifs (« Abbas » rapproché de
« AMRU AL-ABSI ») ; trop stricte, elle manque les variantes de translittération.
Les seuils actuels ont été calibrés sur le portefeuille réel — toute modification
doit être retestée sur les deux jeux de cas.

**Les montants historiques.** Erreur récurrente, trouvée à trois reprises à des
endroits différents : recalculer un montant passé sur des données actuelles.
Commission, caution, restitution. Vérifier systématiquement qu'un calcul portant
sur le passé s'appuie sur une valeur mémorisée, pas sur l'état courant.

---

## 7. Ce qui reste à faire

Par ordre d'importance :

1. **Activer la RLS Supabase** — le point le plus sérieux
2. **Sortir les données du blob JSON unique** vers des tables relationnelles
3. **Passer le dépôt GitHub en privé**
4. **Ajouter la recherche** aux modules qui en manquent : Studios meublés,
   Caisse & dépenses, Agents, Obligations, Diffusion, Charges & factures
5. **Compléter les listes de sanctions** — seul le Comité 1267 (Al-Qaida/EIIL)
   est intégré ; manquent Libye, Soudan, Corée du Nord, Mali, Haïti
6. **Écart de 10 000 F** constaté sur un relevé propriétaire, jamais expliqué

---

## 8. Comment travailler sur ce fichier

**Vérifier la syntaxe avant toute livraison.** Le JSX est transpilé dans le
navigateur : une faute de structure produit une page blanche, sans message
visible ailleurs que dans la console. Extraire le contenu du
`<script type="text/babel">` et le passer à un analyseur Babel évite cela.

Attention : la compilation ne détecte pas les variables utilisées mais non
déclarées. C'est ainsi qu'un écran a été cassé — le code était syntaxiquement
valide, mais appelait un état qui n'existait pas dans son composant.

**Tester en ouvrant le fichier.** Double-clic depuis le dossier : l'écran de
connexion doit apparaître. Page blanche = ne pas déployer.

**Déploiement.** Un seul fichier à déposer sur GitHub, Netlify publie
automatiquement en une à deux minutes. Le quota Netlify de l'agence est limité :
espacer les déploiements, un par jour au maximum.

**Rythme.** L'application a subi plus de cent modifications en trois semaines,
souvent plusieurs déploiements par jour. Cela a causé au moins deux
interruptions de service. Grouper les corrections et déployer le matin.
